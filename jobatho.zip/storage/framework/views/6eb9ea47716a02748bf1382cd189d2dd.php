<div <?php echo e($attributes->merge(['class' => 'bg-gray-50 
    border border-gray-200 rounded'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH E:\Apache24\htdocs\jobatho\resources\views/components/card.blade.php ENDPATH**/ ?>