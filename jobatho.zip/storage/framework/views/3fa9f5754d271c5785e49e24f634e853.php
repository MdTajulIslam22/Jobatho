<?php
    echo "Now it is new view";
    echo "<br>";
    echo "This View should display when localhost ran";
?><?php /**PATH E:\Apache24\htdocs\laragigs\resources\views/newView.blade.php ENDPATH**/ ?>