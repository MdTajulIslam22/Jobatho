

<h1>POSTING</h1>
<?php $__currentLoopData = $posting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1>
        <a href="/post/<?php echo e($post['id']); ?>">
        <?php echo e($post['title']); ?></h1></a>
    <h4><?php echo e($post['content']); ?></h4>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\Apache24\htdocs\laragigs\resources\views/listing.blade.php ENDPATH**/ ?>